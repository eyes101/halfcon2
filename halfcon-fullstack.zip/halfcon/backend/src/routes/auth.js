// auth.js
import { db } from '../config/db.js';
import { hashPassword, verifyPassword, newId, newSessionToken } from '../middleware/auth-crypto.js';
import { requireAuth } from '../middleware/requireAuth.js';

const SESSION_DAYS = 7;

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function registerAuthRoutes(app) {
  // POST /api/auth/register  { name, email, password, phone? }
  app.post('/api/auth/register', (req, res) => {
    const { name, email, password, phone } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'name, email and password are required' });
    }
    if (!isValidEmail(email)) {
      return res.status(400).json({ error: 'Invalid email address' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters' });
    }
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }

    const { hash, salt } = hashPassword(password);
    const id = newId();
    db.prepare(`INSERT INTO users (id, name, email, password_hash, password_salt, role, phone)
                VALUES (?, ?, ?, ?, ?, 'customer', ?)`)
      .run(id, name, email.toLowerCase(), hash, salt, phone || null);

    const token = newSessionToken();
    const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000).toISOString();
    db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)').run(token, id, expiresAt);

    res.cookie('halfcon_session', token, { httpOnly: true, maxAge: SESSION_DAYS * 86400000, sameSite: 'Lax' });
    res.status(201).json({ user: { id, name, email: email.toLowerCase(), role: 'customer' }, token });
  });

  // POST /api/auth/login  { email, password }
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'email and password are required' });
    }
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
    if (!user || !verifyPassword(password, user.password_salt, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = newSessionToken();
    const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000).toISOString();
    db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)').run(token, user.id, expiresAt);

    res.cookie('halfcon_session', token, { httpOnly: true, maxAge: SESSION_DAYS * 86400000, sameSite: 'Lax' });
    res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role }, token });
  });

  // POST /api/auth/logout
  app.post('/api/auth/logout', requireAuth, (req, res) => {
    const token = req.cookies.halfcon_session || (req.headers.authorization || '').replace('Bearer ', '');
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    res.clearCookie('halfcon_session');
    res.json({ ok: true });
  });

  // GET /api/auth/me
  app.get('/api/auth/me', requireAuth, (req, res) => {
    res.json({ user: req.user });
  });
}
