// payments.js
//
// IMPORTANT — READ ME:
// This module implements the FULL payment *flow* (create payment intent,
// confirm payment, webhook handler, order status sync) using a provider-agnostic
// pattern that matches how Stripe, Paystack, and Flutterwave all work:
//   1. Client asks backend to create a "payment intent" for an order
//   2. Backend calls provider API, gets back a client secret / checkout URL
//   3. Customer pays on the provider's hosted page or embedded widget
//   4. Provider calls our webhook to confirm payment server-side (the ONLY
//      trustworthy confirmation — never trust a client-side "success" redirect alone)
//   5. We mark the order paid and unlock staff fulfillment
//
// Because this project was built in a sandbox with no live provider keys,
// PAYMENT_PROVIDER defaults to 'manual' — a stand-in that lets you fully
// test the order → checkout → paid → staff fulfillment pipeline end-to-end
// without any external account. Swap in real keys and flip PAYMENT_PROVIDER
// to go live — see README "Connecting a real payment provider".
import { db } from '../config/db.js';
import { newId } from '../middleware/auth-crypto.js';
import { requireAuth, requireRole } from '../middleware/requireAuth.js';

const PAYMENT_PROVIDER = process.env.PAYMENT_PROVIDER || 'manual';

export function registerPaymentRoutes(app) {
  // POST /api/orders/:id/checkout — customer starts payment for their order
  app.post('/api/orders/:id/checkout', requireAuth, (req, res) => {
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.user_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
    if (!['pending', 'awaiting_payment'].includes(order.status)) {
      return res.status(400).json({ error: `Order is already ${order.status}` });
    }

    const paymentId = newId();

    if (PAYMENT_PROVIDER === 'manual') {
      // TEST MODE: simulate a provider checkout session synchronously.
      db.prepare(`INSERT INTO payments (id, order_id, provider, provider_ref, amount_cents, currency, status)
                  VALUES (?, ?, 'manual', ?, ?, ?, 'initiated')`)
        .run(paymentId, order.id, `manual_${paymentId.slice(0, 8)}`, order.total_cents, order.currency);
      db.prepare("UPDATE orders SET status = 'awaiting_payment', updated_at = datetime('now') WHERE id = ?")
        .run(order.id);

      return res.json({
        mode: 'manual_test',
        message: 'Test-mode checkout created. Call POST /api/payments/:id/simulate-success to complete it (or wire up a real provider — see README).',
        payment_id: paymentId,
        amount_cents: order.total_cents,
        currency: order.currency,
      });
    }

    if (PAYMENT_PROVIDER === 'stripe') {
      // Real integration shape (requires STRIPE_SECRET_KEY env var + `stripe` npm package):
      //
      // import Stripe from 'stripe';
      // const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
      // const session = await stripe.checkout.sessions.create({
      //   mode: 'payment',
      //   line_items: order.items.map(i => ({
      //     price_data: { currency: order.currency, product_data: { name: i.service_name }, unit_amount: i.unit_price_cents },
      //     quantity: i.quantity,
      //   })),
      //   success_url: `${process.env.FRONTEND_URL}/orders/${order.id}?paid=1`,
      //   cancel_url: `${process.env.FRONTEND_URL}/orders/${order.id}`,
      //   metadata: { order_id: order.id, payment_id: paymentId },
      // });
      // db.prepare(`INSERT INTO payments (...) VALUES (...)`).run(paymentId, order.id, 'stripe', session.id, ...);
      // return res.json({ mode: 'stripe', checkout_url: session.url });
      return res.status(501).json({ error: 'Stripe integration scaffolded but not wired — add STRIPE_SECRET_KEY and uncomment the integration block in payments.js' });
    }

    return res.status(400).json({ error: `Unknown PAYMENT_PROVIDER: ${PAYMENT_PROVIDER}` });
  });

  // POST /api/payments/:id/simulate-success — TEST MODE ONLY, mimics a webhook firing
  app.post('/api/payments/:id/simulate-success', requireAuth, (req, res) => {
    if (PAYMENT_PROVIDER !== 'manual') {
      return res.status(400).json({ error: 'Only available when PAYMENT_PROVIDER=manual (test mode)' });
    }
    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Payment not found' });

    markPaymentSucceeded(payment.id, payment.order_id);
    res.json({ ok: true, order: db.prepare('SELECT * FROM orders WHERE id = ?').get(payment.order_id) });
  });

  // POST /api/webhooks/payment — real provider webhook target (Stripe/Paystack/Flutterwave)
  // This endpoint is intentionally NOT behind requireAuth — providers call it server-to-server.
  // In production you MUST verify the signature header before trusting the payload.
  app.post('/api/webhooks/payment', (req, res) => {
    // --- Stripe example signature verification (uncomment when wired up) ---
    // const sig = req.headers['stripe-signature'];
    // let event;
    // try {
    //   event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
    // } catch (err) {
    //   return res.status(400).json({ error: 'Invalid signature' });
    // }
    // if (event.type === 'checkout.session.completed') {
    //   const { order_id, payment_id } = event.data.object.metadata;
    //   markPaymentSucceeded(payment_id, order_id);
    // }

    res.status(501).json({
      error: 'Webhook receiver scaffolded but no provider connected (PAYMENT_PROVIDER=manual). ' +
             'Wire up signature verification for your provider before going live.',
    });
  });

  // GET /api/admin/payments — staff view of all payments
  app.get('/api/admin/payments', requireAuth, requireRole('staff', 'admin'), (req, res) => {
    const rows = db.prepare('SELECT * FROM payments ORDER BY created_at DESC').all();
    res.json({ payments: rows });
  });
}

function markPaymentSucceeded(paymentId, orderId) {
  db.prepare("UPDATE payments SET status = 'succeeded' WHERE id = ?").run(paymentId);
  db.prepare("UPDATE orders SET status = 'paid', updated_at = datetime('now') WHERE id = ?").run(orderId);
}
