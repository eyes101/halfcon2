// api/client.js
const API_BASE = '/api';

async function apiFetch(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const config = {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  };
  const res = await fetch(url, config);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `API error: ${res.status}`);
  return data;
}

export const api = {
  auth: {
    register: (name, email, password, phone) =>
      apiFetch('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name, email, password, phone }),
      }),
    login: (email, password) =>
      apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      }),
    getMe: () => apiFetch('/auth/me'),
    logout: () => apiFetch('/auth/logout', { method: 'POST' }),
  },
  services: {
    list: (category) =>
      apiFetch(`/services${category ? `?category=${category}` : ''}`),
    get: (slug) => apiFetch(`/services/${slug}`),
    adminList: () => apiFetch('/admin/services'),
    adminCreate: (data) =>
      apiFetch('/admin/services', { method: 'POST', body: JSON.stringify(data) }),
    adminUpdate: (id, data) =>
      apiFetch(`/admin/services/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    adminDelete: (id) =>
      apiFetch(`/admin/services/${id}`, { method: 'DELETE' }),
  },
  orders: {
    create: (items, notes, address, scheduled_for) =>
      apiFetch('/orders', {
        method: 'POST',
        body: JSON.stringify({ items, notes, address, scheduled_for }),
      }),
    list: (status) =>
      apiFetch(`/orders${status ? `?status=${status}` : ''}`),
    get: (id) => apiFetch(`/orders/${id}`),
    updateStatus: (id, status) =>
      apiFetch(`/orders/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }),
  },
  payments: {
    checkout: (orderId) =>
      apiFetch(`/orders/${orderId}/checkout`, { method: 'POST' }),
    simulateSuccess: (paymentId) =>
      apiFetch(`/payments/${paymentId}/simulate-success`, { method: 'POST' }),
  },
  messages: {
    list: (orderId) => apiFetch(`/orders/${orderId}/messages`),
    send: (orderId, body) =>
      apiFetch(`/orders/${orderId}/messages`, {
        method: 'POST',
        body: JSON.stringify({ body }),
      }),
  },
  admin: {
    users: () => apiFetch('/admin/users'),
    payments: () => apiFetch('/admin/payments'),
  },
};
